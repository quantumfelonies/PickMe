-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2023 at 09:32 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pickme`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adm.email` varchar(45) NOT NULL,
  `adm.password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adm.email`, `adm.password`) VALUES
('electionadmin@strathmore.edu', 'ratatata2023');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_candidates`
--

CREATE TABLE `tbl_candidates` (
  `can.id` int(11) NOT NULL,
  `std.email` varchar(60) NOT NULL,
  `post.id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_candidates`
--

INSERT INTO `tbl_candidates` (`can.id`, `std.email`, `post.id`) VALUES
(1, 'myles.johnson@strathmore.edu', 3),
(2, 'patience.kamanthe@strathmore.edu', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE `tbl_course` (
  `cour.id` int(11) NOT NULL,
  `cour.name` varchar(120) NOT NULL,
  `cour.code` varchar(6) NOT NULL,
  `cour.duration` enum('1','2','3','4','5') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`cour.id`, `cour.name`, `cour.code`, `cour.duration`) VALUES
(1, 'Bachelor Of Science In Informatics And Computer Science', 'BICS', '4'),
(3, 'Diploma in Procurement', 'DiP', '2'),
(4, 'Master of Applied Philosophy and Ethics', 'MAPE', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_elections`
--

CREATE TABLE `tbl_elections` (
  `ele.id` int(11) NOT NULL,
  `ele.title` varchar(45) NOT NULL,
  `ele.start_date` date NOT NULL,
  `ele.end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_elections`
--

INSERT INTO `tbl_elections` (`ele.id`, `ele.title`, `ele.start_date`, `ele.end_date`) VALUES
(1, 'School Council President', '2023-07-12', '2023-07-14'),
(2, 'School Council Vice President', '2023-07-12', '2023-07-14'),
(3, 'Academic Representative', '2023-07-12', '2023-07-14'),
(4, 'Financial Representative', '2023-07-12', '2023-07-14');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_intakes`
--

CREATE TABLE `tbl_intakes` (
  `intk.id` int(11) NOT NULL,
  `intk.detail` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_intakes`
--

INSERT INTO `tbl_intakes` (`intk.id`, `intk.detail`) VALUES
(1, 'June 2023'),
(2, 'January 2021'),
(3, 'May 2022'),
(4, 'March 2022'),
(5, 'May 2023');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_position`
--

CREATE TABLE `tbl_position` (
  `pos.id` int(11) NOT NULL,
  `pos.name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_position`
--

INSERT INTO `tbl_position` (`pos.id`, `pos.name`) VALUES
(1, 'Financial Representative'),
(2, 'Academic Representative'),
(3, 'President'),
(4, 'Vice President'),
(5, 'Class Respresentative'),
(6, 'Public Relations Representative');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `std.email` varchar(60) NOT NULL,
  `std.fname` varchar(45) NOT NULL,
  `std.other_names` varchar(45) DEFAULT NULL,
  `std.lname` varchar(45) NOT NULL,
  `std.phone` varchar(10) NOT NULL,
  `std.gender` enum('Female','Male','Other') NOT NULL,
  `std.year_of _completion` year(4) NOT NULL,
  `intk.id` int(11) NOT NULL,
  `cour.id` int(11) NOT NULL,
  `is_verfiied` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`std.email`, `std.fname`, `std.other_names`, `std.lname`, `std.phone`, `std.gender`, `std.year_of _completion`, `intk.id`, `cour.id`, `is_verfiied`) VALUES
('bramwel.tum@strathmore.edu', 'Bramwel', NULL, 'Tum', '0734565492', 'Male', 2025, 1, 3, '0'),
('charis.orony@strathmore.edu', 'Charis', 'N.', 'Orony', '0790461625', 'Other', 2025, 2, 1, '0'),
('ian.kirema@strathmore.edu', 'Ian', NULL, 'Kirema', '0734567324', 'Male', 2023, 2, 4, '0'),
('kyla.arunga@strathmore.edu', 'Kyla', NULL, 'Arunga', '0759967329', 'Female', 2024, 2, 1, '0'),
('myles.johnson@strathmore.edu', 'Myles', NULL, 'Johnson', '0767925429', 'Male', 2026, 3, 1, '0'),
('patience.kamanthe@strathmore.edu', 'Patience', NULL, 'Kamanthe', '0745671528', 'Female', 2026, 4, 1, '0'),
('ruweida.ismael@strathmore.edu', 'Ruweida', NULL, 'Ismael', '0768932157', 'Female', 2027, 1, 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_votes`
--

CREATE TABLE `tbl_votes` (
  `vote.id` int(11) NOT NULL,
  `ele.id` int(45) NOT NULL,
  `can.id` int(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_winners`
--

CREATE TABLE `tbl_winners` (
  `win.id` int(11) NOT NULL,
  `can.id` int(11) NOT NULL,
  `post.id` int(11) NOT NULL,
  `ele.id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adm.email`);

--
-- Indexes for table `tbl_candidates`
--
ALTER TABLE `tbl_candidates`
  ADD PRIMARY KEY (`can.id`),
  ADD KEY `post.id` (`post.id`),
  ADD KEY `std.email` (`std.email`);

--
-- Indexes for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD PRIMARY KEY (`cour.id`),
  ADD UNIQUE KEY `cour.name` (`cour.name`),
  ADD UNIQUE KEY `cour.code` (`cour.code`);

--
-- Indexes for table `tbl_elections`
--
ALTER TABLE `tbl_elections`
  ADD PRIMARY KEY (`ele.id`);

--
-- Indexes for table `tbl_intakes`
--
ALTER TABLE `tbl_intakes`
  ADD PRIMARY KEY (`intk.id`);

--
-- Indexes for table `tbl_position`
--
ALTER TABLE `tbl_position`
  ADD PRIMARY KEY (`pos.id`);

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`std.email`),
  ADD KEY `intk_id` (`intk.id`),
  ADD KEY `cour_id` (`cour.id`);

--
-- Indexes for table `tbl_votes`
--
ALTER TABLE `tbl_votes`
  ADD PRIMARY KEY (`vote.id`),
  ADD KEY `ele.id` (`ele.id`),
  ADD KEY `can.id` (`can.id`);

--
-- Indexes for table `tbl_winners`
--
ALTER TABLE `tbl_winners`
  ADD PRIMARY KEY (`win.id`),
  ADD KEY `eleid` (`ele.id`),
  ADD KEY `canid` (`can.id`),
  ADD KEY `posid` (`post.id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_candidates`
--
ALTER TABLE `tbl_candidates`
  MODIFY `can.id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_course`
--
ALTER TABLE `tbl_course`
  MODIFY `cour.id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_elections`
--
ALTER TABLE `tbl_elections`
  MODIFY `ele.id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_intakes`
--
ALTER TABLE `tbl_intakes`
  MODIFY `intk.id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_position`
--
ALTER TABLE `tbl_position`
  MODIFY `pos.id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_votes`
--
ALTER TABLE `tbl_votes`
  MODIFY `vote.id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_winners`
--
ALTER TABLE `tbl_winners`
  MODIFY `win.id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_candidates`
--
ALTER TABLE `tbl_candidates`
  ADD CONSTRAINT `post.id` FOREIGN KEY (`post.id`) REFERENCES `tbl_position` (`pos.id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `std.email` FOREIGN KEY (`std.email`) REFERENCES `tbl_students` (`std.email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD CONSTRAINT `cour_id` FOREIGN KEY (`cour.id`) REFERENCES `tbl_course` (`cour.id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `intk_id` FOREIGN KEY (`intk.id`) REFERENCES `tbl_intakes` (`intk.id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_votes`
--
ALTER TABLE `tbl_votes`
  ADD CONSTRAINT `can.id` FOREIGN KEY (`can.id`) REFERENCES `tbl_candidates` (`can.id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ele.id` FOREIGN KEY (`ele.id`) REFERENCES `tbl_elections` (`ele.id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_winners`
--
ALTER TABLE `tbl_winners`
  ADD CONSTRAINT `canid` FOREIGN KEY (`can.id`) REFERENCES `tbl_candidates` (`can.id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `eleid` FOREIGN KEY (`ele.id`) REFERENCES `tbl_elections` (`ele.id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `posid` FOREIGN KEY (`post.id`) REFERENCES `tbl_position` (`pos.id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
